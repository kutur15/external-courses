
function MyFuncSprint (){ 
    var NumberArr = [1, 2, 5];
var i
    
    for (i = 0; i < NumberArr.length; i++) {
       // if (i % 2 == 0) {
       // n = n + 1
      //console.log( NumberArr [i] + " Число элементов: " + NumberArr.length);
      console.log( NumberArr [i] + " " + NumberArr.length);
    }
               
    
};
module.exports = MyFuncSprint ();