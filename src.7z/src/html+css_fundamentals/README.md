tags: html, css, basics, fundamentals, task

# Задание 1

[Пройдите все уровни](http://flukeout.github.io/).

# Задание 2

[Проверьте знания о `position`](https://htmlacademy.ru/courses/45).

# Задание 3

Создайте подобную кнопку.

<p align="center">
    <img
        width='250'
        title='HTML'
        src="https://css-tricks.com/wp-content/uploads/2013/10/css-button.png"
    />
</p>

Обратите внимание на несколько границ, способ добавления звезд, градиент, закругления границ.

# Задание 4

Выполните следующее [задание](http://htmlbook.ru/practical/hod-konyom).

# Задание 5

Выполните следующее [задание](http://htmlbook.ru/practical/ramka).

# Задание 6

[Пройдите игру](https://flexboxfroggy.com/#ru).

# Задание 7

[Пройдите игру](http://www.flexboxdefense.com/).

# Задание 8

[Пройдите игру](http://cssgridgarden.com/#ru).

# Задание 9

[Поправьте сайдбар неколькими способами](https://codepen.io/chriscoyier/pen/ClGcF).

