var obj = {};
    obj.a = 1;
    obj.b = "phone";
    obj.c = null;
    delete obj.b;